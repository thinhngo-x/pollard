emit() { s=$1; shift; line="{\"step\": $s"; for kv in "$@"; do line="$line, \"${kv%%=*}\": ${kv#*=}"; done; echo "$line}" >> "$POLLARD_METRICS"; }
emit 1 loss=2.0 acc=0.1
emit 2 loss=1.5 acc=0.2
case "${MODE:-ok}" in
  ckpt) printf 'fake weights %s\n' "$POLLARD_NODE_ID" > "$POLLARD_CKPT_DIR/step2.pt" ;;
  fail) exit 3 ;;
  kill) kill -INT 0; sleep 5 ;;
esac
